var http = require('http');
var fs = require('fs');
let url = require('url');

function templateHTML(title, list, body){
  return `
  <!doctype html>
  <html>
  <head>
    <title>WEB1 - ${title} </title>
    <meta charset="utf-8">
  </head>
  <body>
    <h1><a href="/">WEB</a></h1>
    ${list}
    ${body}
  </body>
  </html>
  `;
}
function templatelist(filelist){
  let list = '<ul>';
  let i = 0;
  while(i < filelist.length){
    list = list + `<li><a href="/?id=${filelist[i]}">${filelist[i]}</a></li>`;
    i = i + 1;
  }
  list = list + '</ul>';
  return list;
}

var app = http.createServer(function(request,response){
    var _url = request.url;
    let querydata = url.parse(_url, true).query;
    let pathname = url.parse(_url, true).pathname;

    if(pathname === '/'){
      if(querydata.id === undefined){
          let title = 'Welcome2';
          let description = 'Hello node.js';
          let dir = 'C:/Users/owNer/Desktop/web/data'
          fs.readdir(dir,function(err, filelist){
            /*
            let list =`<ol>
              <li><a href="/?id=html">HTML</a></li>
              <li><a href="/?id=css">CSS</a></li>
              <li><a href="/?id=javascript">JavaScript</a></li>
            </ol>`;
            */
            let list = templatelist(filelist);
            let template= templateHTML(title, list, `<h2>${title}</h2>${description}`);
            response.writeHead(200);
            response.end(template);
          })

      }else{
        let dir = 'C:/Users/owNer/Desktop/web/data'
        fs.readdir(dir,function(err, filelist){
          fs.readFile(`data/${querydata.id}`, 'utf8', function(err,description){
            let title = querydata.id;
            let list = templatelist(filelist);
            let template= templateHTML(title, list, `<h2>${title}</h2>${description}`);
            response.writeHead(200);
            response.end(template);
          });
        });
      }
    }else{
      response.writeHead(404);
      response.end('Not found');
    }
});
app.listen(3000);

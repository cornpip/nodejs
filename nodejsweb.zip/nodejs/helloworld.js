let name ='bit48';
let letter = "hi my "+name+" humm that's cool what\
 \n are you doing" +name;
console.log(letter);

let age = 30;

function showage(){
  console.log(age);
  var age = 20;
}
showage()


clear = 3;
if (1){
  function test(clear){
    return clear;
  }
  console.log(test(clear))
}

a = 5;
console.log(a);

let path = require('path');

let b = '../password.js';
console.log(path.parse(b).base);

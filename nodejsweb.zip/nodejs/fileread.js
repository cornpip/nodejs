const fs=require('fs');
fs.readFile('sample.txt', 'utf8', function(err, data){
console.log(data);
});

// console.log(a); 현재보기에는 data변수는 안에서만 효과가 있고
// readfile 자체를 변수로 잡으면 에러는 안뜨지만 파일을 불러오지못한다
// 파일을 불러온 정보를 그냥 기본적인 변수로는 잡아둘수없는 듯 하다

// 현재로는 fs.readFile 안으로만 파일을 불러온 변수를 사용할 수 있다.
